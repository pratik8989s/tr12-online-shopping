package com.shopping.service;

import com.shopping.beans.RegisterBean;
import com.shopping.dao.UserupdateDAO;

public class UpdateService {
	public boolean update(RegisterBean rb)
	{
	  UserupdateDAO udao=new UserupdateDAO();
		
		return udao.update(rb);
	}
}

