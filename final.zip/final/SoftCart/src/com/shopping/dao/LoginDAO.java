	package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.shopping.util.DBUtil;

public class LoginDAO {
	public static boolean validate(String name,String pass){  
		boolean status=false;  
		try{  
		
		 Connection con = DBUtil.getDBCon(); 
		      
		PreparedStatement ps=con.prepareStatement(  "select cust_name, password from customer1 where CUST_NAME=? and PASSWORD=?");  
		ps.setString(1,name);  
		ps.setString(2,pass);  
		ResultSet rs=ps.executeQuery();  
		
		if(rs.next())
		{
			status=true;
		}
		else
		{
			status=false;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}  
		return status;  
		}  

}

