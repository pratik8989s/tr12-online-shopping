package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.shopping.beans.RegisterBean;
import com.shopping.util.DBUtil;

public class UserupdateDAO {
	public boolean update(RegisterBean rb)
	{
		Connection con=null;
		PreparedStatement ps=null;
		boolean b = false;
		try{
		  con = DBUtil.getDBCon(); 
		      
		
		 ps=con.prepareStatement("UPDATE CUSTOMER1 SET CUST_NAME=?,CUSTOMER_ADDR=?,CUSTOMER_PHNO=?,EMAIL_ID=?,PASSWORD=? WHERE CUSTOMER_ID=?");   
		
		
		ps.setString(1, rb.getName());
		ps.setString(2, rb.getAddress());
		ps.setString(3,rb.getPhNo());
		ps.setString(4,rb.getEmailID());
		ps.setString(5,rb.getPasswd());
		ps.setString(6,rb.getId());
		int result =ps.executeUpdate();
		
		 if(result>0){
		    	b = true;
		    	con.commit();
		    	return b;
		    }}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return b;
		
		
}
	
}
