package com.shopping.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shopping.beans.OrderBean;
import com.shopping.beans.ProductBean;
import com.shopping.beans.RegisterBean;
import com.shopping.dao.AdminDAO;
import com.shopping.dao.DeleteProductDAO;
import com.shopping.dao.LoginDAO;
import com.shopping.service.CartService;
import com.shopping.service.OrderService;
import com.shopping.service.ProductService;
import com.shopping.service.RegisterService;
import com.shopping.service.UpdateService;
//import com.sun.xml.internal.ws.client.SenderException;



import javax.servlet.RequestDispatcher;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import com.shopping.beans.OrderBean;
import com.shopping.beans.ProductBean;
import com.shopping.beans.RegisterBean;
import com.shopping.service.CartService;
import com.shopping.service.OrderService;
import com.shopping.service.ProductService;
//import com.shopping.dao.RegisterDAO;
import com.shopping.service.RegisterService;
import com.shopping.service.UpdateService;
import com.shopping.dao.AdminDAO;
import com.shopping.dao.DeleteProductDAO;
import javax.servlet.http.HttpSession;
import com.shopping.dao.LoginDAO;

/**
 * Servlet implementation class ShoppingController
 */

public class ShoppingController extends HttpServlet {
	HttpSession sessionObj = null;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		RequestDispatcher rd ;
		// boolean flag = true;
		String cat = req.getParameter("category");
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		
		if (cat== null) {
			if (sessionObj != null)
				sessionObj.invalidate();

			res.sendRedirect("home.jsp");

		}	
		
		else if(cat.equals("logout"))
		{
			 req.getSession().invalidate();
		        res.sendRedirect( "signout.jsp");
		}
		
		else if(cat.equals("adlogout"))
		{
			 req.getSession().invalidate();
		        res.sendRedirect(req.getContextPath() + "/home.jsp");
		}
		

		
		else if (cat.equals("insert")) {
			
			
			 HttpSession session =req.getSession(false);
		      if (session==null||session.isNew())
		    {
		     res.sendRedirect("pageexpired.jsp");
		    } else{
		    	
		    	//System.out.println("session setting interval");
		        session.setMaxInactiveInterval(3000);
		
			//1. retrieving the User Input data
			    
				String name = req.getParameter("name");
				String addr=req.getParameter("addr");
				String phnumber = req.getParameter("contactno");
				String email = req.getParameter("email");
				String password = req.getParameter("passwd");
				
				String cpass=req.getParameter("confirmpasswd");
				
				RegisterBean rb=new RegisterBean(name,addr,phnumber,email,password,cpass);
				
				boolean result = false;
				RegisterService rs=new RegisterService();
				//if(flag){
				result=rs.register(rb);
				
				if(result==true){
					rd = req.getRequestDispatcher("insertsuccess.jsp");
					
					rd.forward(req, res);
				}else
				{
					rd = req.getRequestDispatcher("inserterror.jsp");
					
					rd.forward(req, res);
				}}
		
		}			
				
		else if(cat.equals("login")){
			HttpSession session =req.getSession(false);
		      if (session==null||session.isNew())
		    {
		     res.sendRedirect("pageexpired.jsp");
		    }
		    else{
		    session.setMaxInactiveInterval(3000);
				String name=req.getParameter("user");  
			    String pass=req.getParameter("pwd");  
				session.setAttribute("uname",name);
			    
			    if(LoginDAO.validate(name, pass)){  
			         rd=req.getRequestDispatcher("first.jsp");
			        rd.forward(req,res);  
			    }  
			    else{  
			        pw.print("Sorry username or password error");  
			         rd=req.getRequestDispatcher("login.jsp");  
			        rd.include(req,res);  
			    }  
			    
		    }}
		else if(cat.equals("update")){
			
			 HttpSession session =req.getSession(false);
		      if (session==null||session.isNew())
		    {
		     res.sendRedirect("pageexpired.jsp");
		    } else{
		    	
		    	//System.out.println("session setting interval");
		        session.setMaxInactiveInterval(3000);
			String id=req.getParameter("id");
			String name=req.getParameter("name");
			String addr=req.getParameter("textarea1");
			String contact=req.getParameter("contact");
			String mailId=req.getParameter("mail");
			String passwd=req.getParameter("passwd");
		
		UpdateService ups=new UpdateService();
		
		RegisterBean rb=new RegisterBean(id,name,addr,contact,mailId,passwd);
		//RegisterBean rb=new RegisterBean(id,name,addr,contact,mailId,city,country,postal);
		
		boolean result = false;
		result=ups.update(rb);
		
		if(result){
			rd = req.getRequestDispatcher("insertsuccess.jsp");
			
			rd.forward(req, res);
		}else
		{
			rd = req.getRequestDispatcher("inserterror.jsp");
			
			rd.forward(req, res);
		}}}
		
		else if(cat.equals("adminlogin")){
			
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");
		   } else{
		   	
		   	//System.out.println("session setting interval");
		       session.setMaxInactiveInterval(3000);
			
			String name=req.getParameter("user");  
		    String pass=req.getParameter("passwd");  
			
		    
		    if(AdminDAO.validate(name, pass)){  
		         rd=req.getRequestDispatcher("adminpage.jsp");
		        rd.forward(req,res);  
		    }  
		    else{  
		        pw.print("Invalid Credentials");  
		        rd=req.getRequestDispatcher("adminlogin.jsp");  
		        rd.include(req,res);  
		    }  }
		}
		
		
		if(cat.equals("add")){
			//1. retrieving the User Input data
			
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");

		   } else{
		   	
		   	//System.out.println("session setting interval");
		       session.setMaxInactiveInterval(3000);
			    String pid=req.getParameter("pid");
				String name = req.getParameter("name");
				String pcat = req.getParameter("prodcategory");
				String status = req.getParameter("status");
				String price = req.getParameter("price");
				String pdesc = req.getParameter("pdesc");
				String adminid=req.getParameter("adminid");
				String catid=req.getParameter("catid");
				
				ProductBean pb=new ProductBean(pid,name,pcat,status,price,pdesc,adminid,catid);
				
				boolean result = false;
				ProductService ps=new ProductService();
				
				result=ps.add(pb);
				
				if(result==true){
					pw.print("<script type=\"text/javascript\">");
					pw.print("alert('Product added')");
					pw.print("</script>");
					rd = req.getRequestDispatcher("adminpage.jsp");
					
					rd.forward(req, res);
				}else
				{
					pw.print("<script type=\"text/javascript\">");
					pw.print("alert('Product cannot be added.Try again')");
					pw.print("</script>");
					rd = req.getRequestDispatcher("adminpage.jsp");
					
					rd.forward(req, res);
				}}}
		
		else if(cat.equals("deleteproduct"))
		{
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");
		   } else{
		   	
		   //	System.out.println("session setting interval");
		       session.setMaxInactiveInterval(3000);
			String pid=req.getParameter("product");
			
			 if(DeleteProductDAO.delete(pid)){  
				    pw.print("<script type=\"text/javascript\">");
					pw.print("alert('Product deleted')");
					pw.print("</script>");
		        rd=req.getRequestDispatcher("adminpage.jsp");
		        rd.include(req,res);  
		        
		    }  
		    else{  
		    	pw.print("<script type=\"text/javascript\">");
				pw.print("alert('Product cannot be deleted.Try again')");
				pw.print("</script>");
		        rd=req.getRequestDispatcher("adminpage.jsp");  
		        rd.include(req,res); 
		       
		    }
		}}
		
		else if(cat.equals("updateproduct")){
			
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");
		   } else{
		   	
		   	//System.out.println("session setting interval");
		       session.setMaxInactiveInterval(3000);
			String pid=req.getParameter("id");
			String pname=req.getParameter("name");
			String pcat=req.getParameter("prodcategory");
			String status=req.getParameter("status");
			String price=req.getParameter("price");
			String pdesc=req.getParameter("pdesc");
			String adminid=req.getParameter("adminid");
			String catid=req.getParameter("catid");
			
		ProductService ps=new ProductService();
		
		ProductBean pb=new ProductBean(pid,pname,pcat,status,price,pdesc,adminid,catid);
		
		boolean result = false;
		
		
		result=ps.update(pb);
		
		if(result){
			pw.print("<script type=\"text/javascript\">");
			pw.print("alert('Product updated')");
			pw.print("</script>");
			rd = req.getRequestDispatcher("adminpage.jsp");
			
			rd.include(req, res);
		}else
		{
			pw.print("<script type=\"text/javascript\">");
			pw.print("alert('Product not updated.Try again')");
			pw.print("</script>");
			rd = req.getRequestDispatcher("adminpage.jsp");
			
			rd.include(req, res);
		}}
		}
		else if(cat.equals("pay"))
				{
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");
		   } else{
		   	
			        String id  = req.getParameter("id");
			        String  status= req.getParameter("status");
			        String  mode= req.getParameter("radios");
			        
			        OrderService os=new OrderService();
			        
			        OrderBean ob=new OrderBean(id,status,mode);
			        boolean result = false;
			        
			        result=os.pay(ob);
					
					if(result){
						pw.print("<script type=\"text/javascript\">");
						pw.print("alert(' Order placed successfully ')");
						pw.print("</script>");
						rd = req.getRequestDispatcher("first.jsp");
						
						rd.include(req, res);
					}else
					{
						pw.print("<script type=\"text/javascript\">");
						pw.print("alert('Order not placed.Try again')");
						pw.print("</script>");
						rd = req.getRequestDispatcher("first.jsp");
						
						rd.include(req, res);
					}}
				}
			        
					
				
		
		else if(cat.equals("addtocart"))
		{
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");
		   } else{
		   	
		   //	System.out.println("session setting interval");
		       session.setMaxInactiveInterval(3000);
		        CartService shoppingCart;
		        shoppingCart = (CartService) session.getAttribute("cart");
		        if(shoppingCart == null){
		          shoppingCart = new CartService();
		          session.setAttribute("cart", shoppingCart);
		        }
		        String name = req.getParameter("pname");
		        Integer price = Integer.parseInt(req.getParameter("price"));
		        shoppingCart.addToCart(name, price);
		        session.setAttribute("cart", shoppingCart);
		        try {
		        	PrintWriter out = res.getWriter();
		        
		            /* TODO output your page here. You may use following sample code. */
		           // out.println("<!DOCTYPE html>");
		            out.println("<html>");
		            out.println("<head>");
		            out.println("<title>result</title>");            
		            out.println("</head>");
		            out.println("<body>");
		            out.println("<h1>Product successfully added to cart </h1>");
		            out.println("<form action='first.jsp'>Add more products<input type='submit' value='go'></form>");
		            out.println("<hr>");
		            out.println("<h2>Cart</h2>");
		            HashMap<String, Integer> items = shoppingCart.getCartItems();
		            out.println("<table border='1px'>");
		           
		           /* for(String key: items.keySet()){
		                out.println("<tr><td>"+key+" - </td><td>"+"INR"+items.get(key)+"</td></tr>");
		            }
		            */
		            for(String key: items.keySet()){
		                out.println("<form action='sc'><input type='hidden' name='name' value='"+key+"'><tr><td>"+key+" - </td><td>"+"INR"+items.get(key)+"</td><td><input type='submit' value='delete'><input type='hidden' value='deletecart' name='category'></td></tr></form>");
		            }
		            
		            out.println("<table>");
		            out.println("<form action='order.jsp'><input type='submit' value='Pay'><br><input type='hidden' value='pay' name='category'></form>");
		            out.println("</body>");
		            out.println("</html>");
		            out.close();
		        
		        }catch(IOException e)
		        {
		        	
		        }
		
	}}
		else if(cat.equals("deletecart"))
		{
			HttpSession session =req.getSession(false);
		     if (session==null||session.isNew())
		   {
		    res.sendRedirect("pageexpired.jsp");
		   } else{
		   	
		   	//System.out.println("session setting interval");
		       session.setMaxInactiveInterval(3000);
	        CartService shoppingCart;
	        shoppingCart = (CartService) session.getAttribute("cart");
	        String name = req.getParameter("name");
	        shoppingCart.deleteFromCart(name);
	        session.setAttribute("cart", shoppingCart);
	         shoppingCart = (CartService) session.getAttribute("cart");
	        try {
	        	PrintWriter out = res.getWriter();
	        
	            /* TODO output your page here. You may use following sample code. */
	            out.println("<!DOCTYPE html>");
	            out.println("<html>");
	            out.println("<head>");
	            out.println("<title>Servlet deleteItem</title>");            
	            out.println("</head>");
	            out.println("<body>");
	            HashMap<String, Integer> items = shoppingCart.getCartItems();
	            out.println("<table border='1px'>");
	            
	            for(String key: items.keySet()){
	                out.println("<form action='order.jsp'><input type='hidden' name='name' value='"+key+"'><tr><td>"+key+" - </td><td>"+"INR"+items.get(key)+"</td><td><input type='submit' value='delete'>"
	                		+ "<input type='hidden' value='deletecart' name='category'></td></tr></form>");
	            }
	           
	            out.println("</table>");
	            out.println("<form action='sc'><input type='submit' value='Pay'><br><input type='hidden' value='pay' name='category'></form>");
	            out.println("</body>");
	            out.println("</html>");
	            out.close();
	        }catch(IOException e)
	        {
	        	e.printStackTrace();
	        }
		   
	        
		}
		     
		}
		
	
}
	}




 