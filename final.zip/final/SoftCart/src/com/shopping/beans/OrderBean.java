package com.shopping.beans;

public class OrderBean {

	private String id;
	private String status;
	private String mode;
	public OrderBean(String id, String status, String mode) {
		
		this.id = id;
		this.status = status;
		this.mode = mode;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}


}
