package com.techm.softcart.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.softcart.dao.UserDAO;
import com.techm.softcart.models.User;

public class UserDAOImpl implements UserDAO {
	int i=0;
	
	Connection con;
	public UserDAOImpl() {
			
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++++++++ Driver Loaded ++++++++++++");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "softcart", "loretta");
//			InitialContext ctx=new InitialContext();
//			DataSource ds=(DataSource)ctx.lookup("OraDS");
//			con=ds.getConnection();
			System.out.println("+++++++++++++++ Connected To DB ++++++++++++++");
			
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

		catch (SQLException e) {

			e.printStackTrace();
		} 
	}
	public boolean addUser(User user) {
		boolean isAdded = false;
		try {
		   	String query="insert into soft_user values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, 1);
			ps.setString(2, user.getFirstName());
			ps.setString(3, user.getLastName());
			ps.setString(4, user.getEmail_id());
			ps.setString(5, user.getStreet());
			ps.setString(6, user.getCity_state());
			ps.setString(7,user.getZip_code());	
			
			ps.setString(8, user.getUser_login());
			ps.setString(9, user.getPassword());
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ User Added +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isAdded;
	}
	/*public User getUser(String userId) {
		String query="select * from users where userid = ?";
		User user=null;
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, userId);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				user=new User(
						rs.getString(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5),
						rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}*/
	public boolean validateUser(User user) {
		boolean isValid=false;
		String query="select * from soft_user where user_login = ? and password = ?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, user.getUser_login());
			ps.setString(2, user.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				isValid=true;
				System.out.println("++++++++++++++ User is Valid +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isValid;
	}
	
	
	public boolean Uupdatepass(User user) {
		// TODO Auto-generated method stub
		boolean isAdded = false;
		try {
		   	
		   	String query="update soft_user set password=? where user_login=? ";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, user.getNpassword());
			ps.setString(2, user.getUser_login());
			
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ User Added +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isAdded;
	}
	
	
	public void closeConnection() {
		if(con!=null){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public User getUser(String userId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
