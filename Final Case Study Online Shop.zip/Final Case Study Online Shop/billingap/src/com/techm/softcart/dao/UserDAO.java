package com.techm.softcart.dao;



import com.techm.softcart.models.User;

public interface UserDAO {
	boolean addUser(User user);
	User getUser(String userId);
	boolean validateUser(User user);
	boolean Uupdatepass(User user);
	void closeConnection();
}
