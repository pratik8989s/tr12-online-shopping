package com.techm.softcart.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.softcart.models.Product;
import com.techm.softcart.models.User;

public interface ProductDAO {

	boolean addproduct(Product product);
	boolean deleteproduct(Product product);
	boolean updateproduct(Product product);
	
	void closeConnection();
	
	
}
