package com.techm.softcart.dao;

import com.techm.softcart.models.Cart;
import com.techm.softcart.models.Product;

public interface CartDAO {
	void addcart(Cart cart);
	void closeConnection();
}
