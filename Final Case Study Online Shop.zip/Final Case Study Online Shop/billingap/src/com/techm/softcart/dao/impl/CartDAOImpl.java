package com.techm.softcart.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.techm.softcart.dao.CartDAO;
import com.techm.softcart.models.Cart;

public class CartDAOImpl implements CartDAO {

	
int i=0;
	
	Connection con;
	
public CartDAOImpl() {
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++++++++ Driver Loaded ++++++++++++");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "softcart", "loretta");
//			InitialContext ctx=new InitialContext();
//			DataSource ds=(DataSource)ctx.lookup("OraDS");
//			con=ds.getConnection();
			System.out.println("+++++++++++++++ Connected To DB ++++++++++++++");
			
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

		catch (SQLException e) {

			e.printStackTrace();
		} 
	}
	
	
	public void addcart(Cart cart) {
		// TODO Auto-generated method stub
		
		try {
		   	String query="insert into cart values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, 1);
			ps.setInt(2, cart.getPcart_id());
			ps.setString(3,cart.getPcart_name()); 
			ps.setInt(4,cart.getPsum());
			
			
		
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
	}

	
	
	
	
	
	
	
	
	
	

	public void closeConnection() {
		// TODO Auto-generated method stub
		if(con!=null){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

}













	












	
}