package com.techm.softcart.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;
import com.techm.softcart.dao.ProductDAO;
import com.techm.softcart.models.Product;

public class ProductDAOImpl implements ProductDAO {

	
int i=0;
	
	Connection con;
	
	public ProductDAOImpl() {
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++++++++ Driver Loaded ++++++++++++");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "softcart", "loretta");
//			InitialContext ctx=new InitialContext();
//			DataSource ds=(DataSource)ctx.lookup("OraDS");
//			con=ds.getConnection();
			System.out.println("+++++++++++++++ Connected To DB ++++++++++++++");
			
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

		catch (SQLException e) {

			e.printStackTrace();
		} 
	}
	
	
	
	
	
	
	
	
	
	
	public boolean addproduct(Product product) {
		// TODO Auto-generated method stub
		boolean isAdded = false;
		try {
		   	String query="insert into product values(?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, 1);
			ps.setString(2, product.getProduct_name());
			ps.setString(3, product.getPrice());
			ps.setString(4, product.getModel_no());
			ps.setString(5, product.getCate_name());
			
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ User Added +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isAdded;
	}

	
	public boolean deleteproduct(Product product) {
		// TODO Auto-generated method stub
		
		boolean isAdded = false;
		try {
		   	String query="delete from  product where model_no = ?";
		   	
		 
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
		
			
			ps.setString(1, product.getModel_no());
			
			
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ User Added +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return isAdded;
	}

	public boolean updateproduct(Product product) {
		// TODO Auto-generated method stub
		boolean isAdded = false;
		try {
		   	
		   	String query="update product set product_name=?,price=? where model_no=? ";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, product.getProduct_name());
			ps.setString(2, product.getPrice());
			ps.setString(3, product.getModel_no());
		
			
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ User Added +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isAdded;
	}

	
	
	
	

	
	
	
	public void closeConnection() {
		// TODO Auto-generated method stub
		if(con!=null){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}










	









	









	
}
