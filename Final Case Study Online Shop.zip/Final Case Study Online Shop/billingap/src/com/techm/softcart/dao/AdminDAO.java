package com.techm.softcart.dao;

import com.techm.softcart.models.Admin;
import com.techm.softcart.models.User;

public interface AdminDAO {
	
	//User getUser(String adminId);
	boolean validateAdmin(Admin admin);
	void closeConnection();
	boolean updatepass(Admin admin);
}
