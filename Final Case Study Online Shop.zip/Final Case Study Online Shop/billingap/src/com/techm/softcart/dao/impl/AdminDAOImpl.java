package com.techm.softcart.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.softcart.dao.AdminDAO;
import com.techm.softcart.models.Admin;
import com.techm.softcart.models.User;

public class AdminDAOImpl implements AdminDAO {
Connection con;


public AdminDAOImpl() {
		
	try {
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("+++++++++++++++ Driver Loaded ++++++++++++");
		con = DriverManager.getConnection(
				"jdbc:oracle:thin:@localhost:1521:XE", "softcart", "loretta");
//		InitialContext ctx=new InitialContext();
//		DataSource ds=(DataSource)ctx.lookup("OraDS");
//		con=ds.getConnection();
		System.out.println("+++++++++++++++ Connected To DB ++++++++++++++");
		
	} catch (ClassNotFoundException e) {

		e.printStackTrace();
	}

	catch (SQLException e) {

		e.printStackTrace();
	} 
}

	public boolean validateAdmin(Admin admin) {
		boolean isValid1=false;
		String query="select count(*) from admin where admin_login =? and password = ?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, admin.getAdmin_Id());
			ps.setString(2, admin.getAdmin_password());
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				int temp=rs.getInt(1);
				if(temp==1){
					isValid1=true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isValid1;
	}

	
public boolean updatepass(Admin admin) {
		
		boolean isAdded = false;
		try {
		   	
		   	String query="update admin set password=? where password=? ";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, admin.getAdmin_current());
			ps.setString(2, admin.getAdmin_password());
			
		
			
			
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ User Added +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isAdded;
	}


	
	
	
	public void closeConnection() {
		if(con!=null){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	






}
		
		
		
		
		
		
	

	
/*public boolean validateUser(User user) {
	boolean isValid=false;
	String query="select * from soft_user where user_login = ? and password = ?";
	try {
		PreparedStatement ps=con.prepareStatement(query);
		ps.clearParameters();
		ps.setString(1, user.getUser_login());
		ps.setString(2, user.getPassword());
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			isValid=true;
			System.out.println("++++++++++++++ User is Valid +++++++++++");
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return isValid;
}
*/