package com.techm.softcart.models;

public class Product {
	private int product_id;
	public int getProduct_id() {
		return product_id;
	}



	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}



	public Product(int product_id, String product_name, String price,
			String model_no, String cate_name) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.price = price;
		this.model_no = model_no;
		this.cate_name = cate_name;
	}

	private String product_name;
	private String price;
	private String model_no;
	private String cate_name;
	
	public Product(String product_name, String price, String model_no,
			String cate_name) {
		super();
		this.product_name = product_name;
		this.price = price;
		this.model_no = model_no;
		this.cate_name = cate_name;
	}

	

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getModel_no() {
		return model_no;
	}

	public void setModel_no(String model_no) {
		this.model_no = model_no;
	}

	public String getCate_name() {
		return cate_name;
	}

	public void setCate_name(String cate_name) {
		this.cate_name = cate_name;
	}
	
	
}
