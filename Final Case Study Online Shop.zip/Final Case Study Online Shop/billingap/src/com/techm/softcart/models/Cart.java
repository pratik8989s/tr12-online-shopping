package com.techm.softcart.models;

public class Cart {
	
	int cart_id;
	int pcart_id;
	String pcart_name;
	int psum;
	public Cart(int pcart_id, String pcart_name, int psum) {
		super();
		this.pcart_id = pcart_id;
		this.pcart_name = pcart_name;
		this.psum = psum;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getPcart_id() {
		return pcart_id;
	}
	public void setPcart_id(int pcart_id) {
		this.pcart_id = pcart_id;
	}
	public String getPcart_name() {
		return pcart_name;
	}
	public void setPcart_name(String pcart_name) {
		this.pcart_name = pcart_name;
	}
	public int getPsum() {
		return psum;
	}
	public void setPsum(int psum) {
		this.psum = psum;
	}
	
	
	

}
