package com.techm.softcart.models;

public class User {
	//private int userId;
	private String firstName;
	private String lastName;
	private String email_id;
	private String street;
	private String city_state;
	private String zip_code;
	
	private String user_login;
	private String password;
	private String npassword;
	
	
	
	public String getNpassword() {
		return npassword;
	}
	public void setNpassword(String npassword) {
		this.npassword = npassword;
	}
	public User(String firstName, String lastName, String email_id,
			String street, String city_state, String zip_code,
			String user_login, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email_id = email_id;
		this.street = street;
		this.city_state = city_state;
		this.zip_code = zip_code;
		this.user_login = user_login;
		this.password = password;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	/*public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}*/
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity_state() {
		return city_state;
	}
	public void setCity_state(String city_state) {
		this.city_state = city_state;
	}
	public String getZip_code() {
		return zip_code;
	}
	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUser_login() {
		return user_login;
	}
	public void setUser_login(String user_login) {
		this.user_login = user_login;
	}
	@Override
	public String toString() {
		return "User [firstName=" + firstName
				+ ", lastName=" + lastName + ", email_id=" + email_id
				+ ", street=" + street + ", city_state=" + city_state
				+ ", zip_code=" + zip_code + ", password=" + password
				+ ", user_login=" + user_login + "]";
	}
	
	
	
}
