package com.techm.softcart.models;

public class Admin {
private String admin_Id;
private String admin_password;
private String admin_current;

public String getAdmin_current() {
	return admin_current;
}

public void setAdmin_current(String admin_current) {
	this.admin_current = admin_current;
}

@Override
public String toString() {
	return "Admin [admin_Id=" + admin_Id + ", admin_password=" + admin_password
			+ "]";
}

public String getAdmin_Id() {
	return admin_Id;
}

public void setAdmin_Id(String admin_Id) {
	this.admin_Id = admin_Id;
}

public String getAdmin_password() {
	return admin_password;
}

public void setAdmin_password(String admin_password) {
	this.admin_password = admin_password;
}

public Admin(String admin_Id, String admin_password) {
	super();
	this.admin_Id = admin_Id;
	this.admin_password = admin_password;
}

public Admin() {
	super();
	// TODO Auto-generated constructor stub
}
}
