package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.softcart.dao.AdminDAO;
import com.techm.softcart.dao.UserDAO;
import com.techm.softcart.dao.impl.AdminDAOImpl;
import com.techm.softcart.dao.impl.UserDAOImpl;
import com.techm.softcart.models.Admin;
import com.techm.softcart.models.User;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDao;
    private AdminDAO adminDao;
    
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		userDao = new UserDAOImpl();
		adminDao=new AdminDAOImpl();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=null;
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String d=null;
		
		
		String userId = request.getParameter("userId");
		String password = request.getParameter("password");
			User user = new User();
		user.setUser_login(userId);
		user.setPassword(password);
		boolean isValid = userDao.validateUser(user);
		if (isValid == true) {
			
			/*session=request.getSession();
			session.setMaxInactiveInterval(900);
			System.out.println("++++++++++++ LoginServlet + "+session.getId());
			session.setAttribute("user", user);
			//*******************Setting and retrieving cookies*************//*
			Date date=new Date();
			Cookie c=new Cookie("lastLogin",date.toString());
			response.addCookie(c);
			RequestDispatcher rd=request.getRequestDispatcher("/BillDetailsServlet");
			
			rd.forward(request, response);*/
			
		//	out.println("hello user");
			
			session=request.getSession();
			System.out.println("++++++++++++ LoginServlet + "+session.getId());
			session.setAttribute("user", user);
		
			response.sendRedirect
			("http://localhost:7001/billingap/UserDeatilsServlet");	
			System.out.println("++++++++++++okay++++++++++");
			
		//	response.sendRedirect
			//("http://localhost:7001/billingap/DataFetch.jsp");	
		} else {
			Admin admin = new Admin();
		admin.setAdmin_Id(userId);
		admin.setAdmin_password(password);
		boolean isValid1 = adminDao.validateAdmin(admin);
		
		if (isValid1 == true) {

			response.sendRedirect
			("http://localhost:7001/billingap/Admin1.html");	
			//response.sendRedirect("http://localhost:7001/billingap/Admin.html");
			
			
		} else {
			response.sendRedirect
			("http://localhost:7001/billingap/invaliduser.html");
			
		}
			
		}
		
		
		
				
		
	}
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	@Override
	public void destroy() {
		userDao.closeConnection();
		adminDao.closeConnection();
	}
}
