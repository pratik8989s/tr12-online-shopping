package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.softcart.dao.UserDAO;
import com.techm.softcart.dao.impl.UserDAOImpl;
import com.techm.softcart.models.Admin;
import com.techm.softcart.models.User;

/**
 * Servlet implementation class UpassServlet
 */
public class UpassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDao;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		userDao=new UserDAOImpl();
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String pass=request.getParameter("pass");
		String ulogin=request.getParameter("ulogin");
	
		User user =new User();
		
	user.setNpassword(pass);
	user.setUser_login(ulogin);	
	

		
		
		boolean isAdded=userDao.Uupdatepass(user);
		
		if(isAdded==true){
			
			
			
			out.println("<html>");
out.println("<head>");

out.println("<style>body{height:auto;width:auto;background-image: url('image/paass1.png');background-repeat: no-repeat;background-size:cover;}");


out.println("</style>");


out.println("</head>");
			out.println("<body bgcolor='cyan'>");
			out.println("<center><h3>"+welcomeMsg+"</center>");
			
			out.println("<p>Congratulations !!! You have User Updated password Successfuly...</p>");
			out.println("<BR><A href=login.html>Back !</A>");
			out.println("</body>");
		}else{
			out.println("<body bgcolor='cyan'>");
			
			out.println("<p>Error  During Password Updation!!!</p>");
			
			out.println("</body>");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public void destroy() {
		userDao.closeConnection();
		}
}
