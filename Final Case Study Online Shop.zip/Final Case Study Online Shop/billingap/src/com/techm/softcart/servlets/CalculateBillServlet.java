package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.softcart.models.User;

public class CalculateBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		
		//String userId=request.getParameter("userId");
		User user=(User)session.getAttribute("user");
		
		String cellNo=request.getParameter("cellNo");
		String min=request.getParameter("minutes");
		
		double minutes=Double.parseDouble(request.getParameter("minutes"));
		double bill=calculateBill(minutes);
		session.setAttribute("cellNo", cellNo);
		session.setAttribute("minutes", min);
		session.setAttribute("bill", bill);
		//request.setAttribute("bill", bill);
		
		out.println("<form method='post' action='DisplayBillServlet'>");
		out.println("<body bgcolor='cyan'>");
		out.println("<B>Welcome <I>"+user.getUser_login()+"</I></B>");
		out.println("<br><a href='LogoutServlet'>Logout</A>");
		out.println("<center><h3>"+welcomeMsg+"</h3>");
		out.println("<table border='2'>");
		out.println("<tr><td>Bill for cell No. <B>"+cellNo+" </B>is : "+bill+"</td></tr>");
		out.println("<tr><td><input type=checkbox name=billAction value='print Bill'>Print Bill");
		out.println("   <input type=checkbox name=billAction value='Email Bill'>Email Bill</td></tr>");
		out.println("<tr><td><input type='submit'value='Proceed'>"
				+ "   <input type='reset'value='Clear'></td></tr>");
		out.println("</table>");
		out.println("</center>");
		out.println("</body>");
		out.println("</form>");
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	public double calculateBill(double minutes){
		return minutes * 2;
	}
}
