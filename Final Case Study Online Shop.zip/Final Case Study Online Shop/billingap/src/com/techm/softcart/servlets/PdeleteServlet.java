package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.softcart.dao.ProductDAO;
import com.techm.softcart.dao.impl.ProductDAOImpl;
import com.techm.softcart.models.Admin;
import com.techm.softcart.models.Product;


public class PdeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private ProductDAO productDao;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		productDao=new ProductDAOImpl();
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
	}
	
	
   

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String model_no=request.getParameter("ModelNo");
		
		Product product = new Product();
		product.setModel_no(model_no);
		boolean isAdded=productDao.deleteproduct(product);
		
		if(isAdded==true){
			out.println("<body bgcolor='powderblue'>");
			out.println("<center><h3>"+welcomeMsg+"</center>");
			
			out.println("<p>Congratulations !!! You have deleted product Successfuly...</p>");
			out.println("<BR><A href=Admin1.html>Back !</A>");
			out.println("</body>");
		}else{
			out.println("<body bgcolor='powderblue'>");
			
			out.println("<p>Error  During deletion!!!</p>");
			
			out.println("</body>");
		}
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
	}

	
	
	
	
	
	
	
	
	public void destroy() {
		productDao.closeConnection();
		}
	
}
