package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.softcart.models.User;

/**
 * Servlet implementation class UserDeatilsServlet
 */
public class UserDeatilsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletContext context;
	private String welcomeMsg;
	private String configParam;
    

public void init(ServletConfig config) throws ServletException {
	context=config.getServletContext();
	welcomeMsg=context.getInitParameter("welcomeMsg");
	configParam=config.getInitParameter("testConfigParameter");
}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String val=null;
		HttpSession session=request.getSession();
		System.out.println("+++++++++++++++++ UserDetailsServlet + "+session.getId());
//		String welcomeMsg=getServletConfig().getServletContext().getInitParameter("welcomeMsg");
//		String configParameter=getServletConfig().getInitParameter("testConfigParameter");
		System.out.println("++++++++++++++++++++++++++++ "+configParam+"++++++++");
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		//String userId=request.getParameter("userId");
		User user=(User)session.getAttribute("user");
		Cookie cks[]=request.getCookies();
		if(cks!=null){
		for(int i=0;i<cks.length;i++){
			if(cks[i].getName().equals("lastLogin")){
				val=cks[i].getValue();
				break;
			}
		}
		}
		
		out.println("<html>");
		out.println("<head>");
		out.println("<title>");
		out.println("Choose your category!!");
		out.println("</TITLE>");
		out.println("</head>");
		out.println("<style>");
out.println("body{background-image: url('image/category2.jpg');background-size:cover;height:auto;width:auto;	background-repeat: no-repeat;}");

out.println("a { text-decoration:none;  color:main;font-size:22px; padding: 270px px 0px 900px;  transition:.5s ease;  &:hover {   color:$main-dark;  }}");
out.println("</style>");


		
		
		
		
		//out.println("body{background-size:400px 400px;background-image: url('category.jpg');background-repeat: no-repeat;}");
out.println("<B>Welcome <I>"+user.getUser_login()+"</I>");
out.println("<br><a href='LogoutServlet'>Logout</A>");
out.println("<br><a href='userpass.html'>change password</A>");
		out.println("<div class='form'>");
		out.println("<center>");
		out.println("<form method='post' action='DisplayCateData.jsp'>");

		
		
		

		out.println("<table border='2' border-color='solid black'>");
out.println("<tr><td>CATEGORY NAME :</td><td><select name='catename'><option value='default'>Category</option><option value='book'>book</option><option value='stationary'>stationary</option><option value='watch'>watch</option><option value='accessories'>accessories</option></select>"
		+ "</td></tr>");
		
//out.println("<tr><td>Enter Category Name :</td><td><input type='text'name='catename'>"
	//	+ "</td></tr>");

	
					
		
out.println("<tr><td><input type='submit'value='Display'></td><td>"
		+ "<input type='reset'value='Clear'></td></tr>");
		out.println("</table>");
		//out.println("</center>");
	
		out.println("</form>");
		out.println("</center>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");

		

		
	
		}	
		
		


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	
	@Override
	public void destroy() {
		
		
	}
	
}
