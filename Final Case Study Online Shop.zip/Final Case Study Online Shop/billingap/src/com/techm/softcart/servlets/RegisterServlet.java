package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.softcart.dao.UserDAO;
import com.techm.softcart.dao.impl.UserDAOImpl;
import com.techm.softcart.models.User;

public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserDAO userDao;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		userDao=new UserDAOImpl();
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			
			String firstName=request.getParameter("FirstName");
			String lastName=request.getParameter("LastName");
			String email_id=request.getParameter("Email_id");
			String street=request.getParameter("Street");
			String city_state=request.getParameter("City_State");
			String zip_code=request.getParameter("zip_code");
			String user_login=request.getParameter("userId");
			String password=request.getParameter("password");
		
			
			User user=new User(firstName, lastName, email_id,street,city_state,zip_code,user_login ,password);
			boolean isAdded=userDao.addUser(user);
			if(isAdded==true){
				out.println("<body bgcolor='cyan'>");
				out.println("<center><h3>"+welcomeMsg+"</center>");
				out.println("Welcome <I><B>"+user.getUser_login()+"</B></I>");
				out.println("<p>Congratulations !!! You have Registered Successfuly...</p>");
				out.println("<BR><A href=login.html>Login Now!</A>");
				out.println("</body>");
			}else{
				out.println("<body bgcolor='cyan'>");
				out.println("<center><h3>Welcome To Soft Cart	```````````````````	``	</h3></center>");
				out.println("<p>Error During Registration !!!</p>");
				out.println("<BR><A href=register1.html>Re-Register!</A>");
				out.println("</body>");
			}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	@Override
	public void destroy() {
	userDao.closeConnection();
	}
}
