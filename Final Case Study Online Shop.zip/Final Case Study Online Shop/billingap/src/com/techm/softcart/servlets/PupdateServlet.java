package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.softcart.dao.ProductDAO;
import com.techm.softcart.dao.impl.ProductDAOImpl;
import com.techm.softcart.models.Product;

/**
 * Servlet implementation class PupdateServlet
 */
public class PupdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductDAO productDao;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		productDao=new ProductDAOImpl();
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
       
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String productName=request.getParameter("ProductName");
		String price=request.getParameter("ProductPrice");
		String model_no=request.getParameter("ModelNo");
		
		Product product = new Product();
		product.setPrice(price);
		product.setModel_no(model_no);
		product.setProduct_name(productName);
		
		boolean isAdded=productDao.updateproduct(product);
		
		if(isAdded==true){
			out.println("<body bgcolor='cyan'>");
			out.println("<center><h3>"+welcomeMsg+"</center>");
			
			out.println("<p>Congratulations !!! You have Updated product Successfuly...</p>");
			out.println("<BR><A href=Admin1.html>Back !</A>");
			out.println("</body>");
		}else{
			out.println("<body bgcolor='cyan'>");
			
			out.println("<p>Error  During Updation!!!</p>");
			
			out.println("</body>");
		}
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	public void destroy() {
		productDao.closeConnection();
		}
	
}
