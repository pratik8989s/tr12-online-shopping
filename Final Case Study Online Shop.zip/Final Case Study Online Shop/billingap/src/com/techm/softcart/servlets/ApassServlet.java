package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.softcart.dao.AdminDAO;
import com.techm.softcart.dao.ProductDAO;
import com.techm.softcart.dao.impl.AdminDAOImpl;
import com.techm.softcart.dao.impl.ProductDAOImpl;
import com.techm.softcart.models.Admin;
import com.techm.softcart.models.Product;

/**
 * Servlet implementation class ApassServlet
 */
public class ApassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminDAO adminDao;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		adminDao=new AdminDAOImpl();
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				PrintWriter out=response.getWriter();
				response.setContentType("text/html");
				
				String cpass=request.getParameter("cpass");
				String npass=request.getParameter("npass");
			
			Admin admin =new Admin();
				
			 admin.setAdmin_password(cpass);
			 admin.setAdmin_current(npass);
				
				
				boolean isAdded=adminDao.updatepass(admin);
				
				if(isAdded==true){
					out.println("<body bgcolor='cyan'>");
					out.println("<center><h3>"+welcomeMsg+"</center>");
					
					out.println("<p>Congratulations !!! You have Updated password Successfuly...</p>");
					out.println("<BR><A href=Admin1.html>Back !</A>");
					out.println("</body>");
				}else{
					out.println("<body bgcolor='cyan'>");
					
					out.println("<p>Error  During Password Updation!!!</p>");
					
					out.println("</body>");
				}
				
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public void destroy() {
		adminDao.closeConnection();
		}

}
