package com.techm.softcart.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.softcart.models.User;

public class BillDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletContext context;
	private String welcomeMsg;
	private String configParam;
	@Override
	public void init(ServletConfig config) throws ServletException {
			context=config.getServletContext();
			welcomeMsg=context.getInitParameter("welcomeMsg");
			configParam=config.getInitParameter("testConfigParameter");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String val=null;
		HttpSession session=request.getSession();
		System.out.println("+++++++++++++++++ BillDetailsServlet + "+session.getId());
//		String welcomeMsg=getServletConfig().getServletContext().getInitParameter("welcomeMsg");
//		String configParameter=getServletConfig().getInitParameter("testConfigParameter");
		System.out.println("++++++++++++++++++++++++++++ "+configParam+"++++++++");
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		//String userId=request.getParameter("userId");
		User user=(User)session.getAttribute("user");
		Cookie cks[]=request.getCookies();
		if(cks!=null){
		for(int i=0;i<cks.length;i++){
			if(cks[i].getName().equals("lastLogin")){
				val=cks[i].getValue();
				break;
			}
		}
		}
		out.println("<form method='post' action='CalculateBillServlet'>");
		out.println("<body bgcolor='cyan'>");
		out.println("<B>Welcome <I>"+user.getUser_login()+"</I>");
		out.println("   LAST Login :: "+val+"</B>");
		out.println("<br><a href='LogoutServlet'>Logout</A>");
		out.println("<center><h3>"+welcomeMsg+"</h3>");
		out.println("<table border='2'>");
out.println("<tr><td>Cell No. :</td><td><input type='text'name='cellNo'>"
		+ "</td></tr>");
out.println("<tr><td>Minutes  :</td><td><input type='text'name='minutes'>"
		+ "</td></tr>");
out.println("<tr><td><input type='submit'value='Calculate Bill'></td><td>"
		+ "<input type='reset'value='Clear'></td></tr>");
		out.println("</table>");
		out.println("</center>");
		out.println("</body>");
		out.println("</form>");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
