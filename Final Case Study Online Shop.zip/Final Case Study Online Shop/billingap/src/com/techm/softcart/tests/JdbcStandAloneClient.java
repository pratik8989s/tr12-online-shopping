package com.techm.softcart.tests;

import java.util.Iterator;

import com.techm.softcart.dao.UserDAO;
import com.techm.softcart.dao.impl.UserDAOImpl;
import com.techm.softcart.models.User;

public class JdbcStandAloneClient {

	public static void main(String[] args) {
		UserDAO userDao=new UserDAOImpl();
		
		User user=new User("Gaurav","Kudale","a@gmail.com","Paud road","Pune,Maharashtra","123455","bhu","12345678");
	boolean isAdded=userDao.addUser(user);
		System.out.println("User Added :: "+isAdded);
//		userDao.addUser(new User("Amol","Joshi","amol@123","amol123",
//				"8899999999","amol@abc.in"));
//		User user=userDao.getUser("softcart@123");
//		System.out.println(user);
//		User newUser=new User("Ajit", "Joshi", "softcart@123", 
//				"softcart123", "9850676160",
//				"softcart@abc.com");
//		userDao.updateUser(newUser);
//		
//		user=userDao.getUser("softcart@123");
//		System.out.println(user);
//		System.out.println("------------------------------------");
//		Iterator<User> itr=userDao.getAllUsers().iterator();
//		while(itr.hasNext()){
//			System.out.println(itr.next());
//		}
//		
//		userDao.getFirstUser();
		userDao.closeConnection();
		
	}

}
